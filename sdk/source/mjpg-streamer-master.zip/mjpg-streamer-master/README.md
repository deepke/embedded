mjpg-streamer
=============

Fork of http://sourceforge.net/projects/mjpg-streamer/